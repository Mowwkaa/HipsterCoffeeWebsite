let navbar = document.querySelector(".navbar");

document.querySelector("#menu-btn").oncklick = () => {
  navbar.classList.toggle("active");
};

let cardItem = document.querySelector(".cart-items-container");

document.querySelector("#cart-btn").oncklick = () => {
  cardItem.classList.toggle("active");
};
